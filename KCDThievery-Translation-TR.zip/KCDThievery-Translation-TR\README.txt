KCD Thievery - Turkish translation pack
=======================================

WHAT THIS IS
A language-only module. It contains no DLL and no assets.
It must be enabled TOGETHER WITH the main "KCDThievery" module.

HOW TO TRANSLATE
Open ModuleData/Languages/TR/kcdt_strings-tur.xml
Each line looks like:

    <string id="kcdt_00ccdc88" text="{0}..." />

- Keep the id exactly as it is. Never change it.
- Only change the text value to Turkish.
- 329 strings contain placeholders like {0}, {1}, {2:0.0}.
  Keep every placeholder, in the same order. Do not translate inside the braces.
- Escape XML characters in the text: & -> &amp;  < -> &lt;  > -> &gt;  " -> &quot;
- Keep the file UTF-8 WITHOUT BOM.
- Do not add or remove <string> lines.

FILE LAYOUT (must stay like this)
KCDThievery.TR/
  SubModule.xml
  ModuleData/Languages/TR/language_data.xml
  ModuleData/Languages/TR/kcdt_strings-tur.xml

TESTING
1. Put the folder in Modules/ next to KCDThievery.
2. Enable both KCDThievery and KCD Thievery - Turkish Translation.
3. Set the game language to Türkçe.
4. Walk around a town, open the lockpicking UI and trigger a knockout to check the UI strings.